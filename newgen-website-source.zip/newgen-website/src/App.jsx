import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { ChevronDown, Menu, X, Play, Shield, Zap, Globe, Users, ArrowRight, Star, CheckCircle } from 'lucide-react';
import AdaptiveSuitModel from './components/AdaptiveSuitModel';
import './App.css';

// Import images
import adaptiveSuit1 from './assets/adaptive_suit_1.png';
import adaptiveSuit2 from './assets/adaptive_suit_2.png';
import adaptiveSuit3 from './assets/adaptive_suit_3.png';
import armin1 from './assets/armin_1.png';
import armin2 from './assets/armin_2.png';
import armin3 from './assets/armin_3.png';

const App = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [activeSection, setActiveSection] = useState('home');
  const [isScrolled, setIsScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 50);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const scrollToSection = (sectionId) => {
    const element = document.getElementById(sectionId);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
      setActiveSection(sectionId);
      setIsMenuOpen(false);
    }
  };

  const navItems = [
    { id: 'home', label: 'Home' },
    { id: 'products', label: 'Products' },
    { id: 'technology', label: 'Technology' },
    { id: 'about', label: 'About' },
    { id: 'contact', label: 'Contact' }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-blue-900 to-slate-800 text-white overflow-x-hidden">
      {/* Navigation */}
      <nav className={`fixed top-0 w-full z-50 transition-all duration-300 ${
        isScrolled ? 'bg-slate-900/95 backdrop-blur-md shadow-lg' : 'bg-transparent'
      }`}>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <motion.div 
              className="flex items-center space-x-2"
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.5 }}
            >
              <div className="w-8 h-8 bg-gradient-to-r from-blue-400 to-cyan-400 rounded-lg flex items-center justify-center">
                <span className="text-slate-900 font-bold text-sm">NG</span>
              </div>
              <span className="text-xl font-bold bg-gradient-to-r from-blue-400 to-cyan-400 bg-clip-text text-transparent">
                NewGen Technologies
              </span>
            </motion.div>

            {/* Desktop Navigation */}
            <div className="hidden md:flex items-center space-x-8">
              {navItems.map((item) => (
                <button
                  key={item.id}
                  onClick={() => scrollToSection(item.id)}
                  className={`text-sm font-medium transition-colors duration-200 hover:text-blue-400 ${
                    activeSection === item.id ? 'text-blue-400' : 'text-gray-300'
                  }`}
                >
                  {item.label}
                </button>
              ))}
              <motion.button
                className="bg-gradient-to-r from-blue-500 to-cyan-500 px-6 py-2 rounded-lg font-medium hover:from-blue-600 hover:to-cyan-600 transition-all duration-200 shadow-lg hover:shadow-xl"
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
              >
                Get Started
              </motion.button>
            </div>

            {/* Mobile menu button */}
            <div className="md:hidden">
              <button
                onClick={() => setIsMenuOpen(!isMenuOpen)}
                className="text-gray-300 hover:text-white"
              >
                {isMenuOpen ? <X size={24} /> : <Menu size={24} />}
              </button>
            </div>
          </div>
        </div>

        {/* Mobile Navigation */}
        <AnimatePresence>
          {isMenuOpen && (
            <motion.div
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: 'auto' }}
              exit={{ opacity: 0, height: 0 }}
              className="md:hidden bg-slate-900/95 backdrop-blur-md"
            >
              <div className="px-4 py-4 space-y-2">
                {navItems.map((item) => (
                  <button
                    key={item.id}
                    onClick={() => scrollToSection(item.id)}
                    className="block w-full text-left px-4 py-2 text-gray-300 hover:text-blue-400 hover:bg-slate-800 rounded-lg transition-colors duration-200"
                  >
                    {item.label}
                  </button>
                ))}
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </nav>

      {/* Hero Section */}
      <section id="home" className="min-h-screen flex items-center justify-center relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-r from-blue-600/20 to-cyan-600/20"></div>
        <div className="absolute inset-0">
          <div className="absolute top-1/4 left-1/4 w-64 h-64 bg-blue-500/10 rounded-full blur-3xl animate-pulse"></div>
          <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-cyan-500/10 rounded-full blur-3xl animate-pulse delay-1000"></div>
        </div>
        
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center relative z-10">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
          >
            <h1 className="text-5xl md:text-7xl font-bold mb-6 bg-gradient-to-r from-blue-400 via-cyan-400 to-blue-400 bg-clip-text text-transparent">
              Future-Ready
              <br />
              Innovation
            </h1>
            <p className="text-xl md:text-2xl text-gray-300 mb-8 max-w-3xl mx-auto">
              Bringing tomorrow's technologies into today's world. Advanced solutions for defense, energy, and human enhancement.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <motion.button
                className="bg-gradient-to-r from-blue-500 to-cyan-500 px-8 py-4 rounded-lg font-semibold text-lg hover:from-blue-600 hover:to-cyan-600 transition-all duration-200 shadow-lg hover:shadow-xl flex items-center justify-center gap-2"
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                onClick={() => scrollToSection('products')}
              >
                Explore Products <ArrowRight size={20} />
              </motion.button>
              <motion.button
                className="border-2 border-blue-400 px-8 py-4 rounded-lg font-semibold text-lg hover:bg-blue-400 hover:text-slate-900 transition-all duration-200 flex items-center justify-center gap-2"
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
              >
                <Play size={20} /> Watch Demo
              </motion.button>
            </div>
          </motion.div>
        </div>

        <motion.div
          className="absolute bottom-8 left-1/2 transform -translate-x-1/2"
          animate={{ y: [0, 10, 0] }}
          transition={{ duration: 2, repeat: Infinity }}
        >
          <ChevronDown size={32} className="text-blue-400" />
        </motion.div>
      </section>

      {/* Products Section */}
      <section id="products" className="py-20 bg-slate-800/50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <h2 className="text-4xl md:text-5xl font-bold mb-6 bg-gradient-to-r from-blue-400 to-cyan-400 bg-clip-text text-transparent">
              Revolutionary Products
            </h2>
            <p className="text-xl text-gray-300 max-w-3xl mx-auto">
              Our flagship innovations are designed to enhance human capabilities and transform global infrastructure.
            </p>
          </motion.div>

          <div className="grid md:grid-cols-2 gap-12 mb-20">
            {/* Adaptive Suit */}
            <motion.div
              initial={{ opacity: 0, x: -30 }}
              whileInView={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8 }}
              viewport={{ once: true }}
              className="bg-gradient-to-br from-slate-800 to-slate-700 rounded-2xl p-8 shadow-2xl hover:shadow-3xl transition-all duration-300"
            >
              <div className="flex items-center mb-6">
                <Shield className="text-blue-400 mr-3" size={32} />
                <h3 className="text-3xl font-bold">Adaptive Suit</h3>
              </div>
              <div className="grid grid-cols-3 gap-4 mb-6">
                <img src={adaptiveSuit1} alt="Adaptive Suit 1" className="rounded-lg shadow-lg hover:scale-105 transition-transform duration-300" />
                <img src={adaptiveSuit2} alt="Adaptive Suit 2" className="rounded-lg shadow-lg hover:scale-105 transition-transform duration-300" />
                <img src={adaptiveSuit3} alt="Adaptive Suit 3" className="rounded-lg shadow-lg hover:scale-105 transition-transform duration-300" />
              </div>
              <p className="text-gray-300 mb-6">
                A lightweight, multifunctional exo-suit with VR integration, biomechanical intelligence, and modular capabilities for industrial, medical, and recreational use.
              </p>
              <div className="space-y-3 mb-6">
                <div className="flex items-center">
                  <CheckCircle className="text-green-400 mr-2" size={16} />
                  <span className="text-sm">Enhanced strength and endurance</span>
                </div>
                <div className="flex items-center">
                  <CheckCircle className="text-green-400 mr-2" size={16} />
                  <span className="text-sm">AI-guided biomechanical adjustments</span>
                </div>
                <div className="flex items-center">
                  <CheckCircle className="text-green-400 mr-2" size={16} />
                  <span className="text-sm">Full VR immersion integration</span>
                </div>
              </div>
              <div className="text-2xl font-bold text-blue-400 mb-4">$300,000</div>
              <motion.button
                className="w-full bg-gradient-to-r from-blue-500 to-cyan-500 py-3 rounded-lg font-semibold hover:from-blue-600 hover:to-cyan-600 transition-all duration-200"
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
              >
                Learn More
              </motion.button>
            </motion.div>

            {/* Project ARMIN */}
            <motion.div
              initial={{ opacity: 0, x: 30 }}
              whileInView={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8 }}
              viewport={{ once: true }}
              className="bg-gradient-to-br from-slate-800 to-slate-700 rounded-2xl p-8 shadow-2xl hover:shadow-3xl transition-all duration-300"
            >
              <div className="flex items-center mb-6">
                <Zap className="text-cyan-400 mr-3" size={32} />
                <h3 className="text-3xl font-bold">Project ARMIN</h3>
              </div>
              <div className="grid grid-cols-3 gap-4 mb-6">
                <img src={armin1} alt="ARMIN 1" className="rounded-lg shadow-lg hover:scale-105 transition-transform duration-300" />
                <img src={armin2} alt="ARMIN 2" className="rounded-lg shadow-lg hover:scale-105 transition-transform duration-300" />
                <img src={armin3} alt="ARMIN 3" className="rounded-lg shadow-lg hover:scale-105 transition-transform duration-300" />
              </div>
              <p className="text-gray-300 mb-6">
                Advanced Renewable Modular Infrastructure Network providing scalable energy, internet connectivity, and water purification for developing regions.
              </p>
              <div className="space-y-3 mb-6">
                <div className="flex items-center">
                  <CheckCircle className="text-green-400 mr-2" size={16} />
                  <span className="text-sm">100% renewable energy generation</span>
                </div>
                <div className="flex items-center">
                  <CheckCircle className="text-green-400 mr-2" size={16} />
                  <span className="text-sm">High-speed internet infrastructure</span>
                </div>
                <div className="flex items-center">
                  <CheckCircle className="text-green-400 mr-2" size={16} />
                  <span className="text-sm">Smart water filtration systems</span>
                </div>
              </div>
              <div className="text-2xl font-bold text-cyan-400 mb-4">Custom Pricing</div>
              <motion.button
                className="w-full bg-gradient-to-r from-cyan-500 to-blue-500 py-3 rounded-lg font-semibold hover:from-cyan-600 hover:to-blue-600 transition-all duration-200"
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
              >
                Get Quote
              </motion.button>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Interactive Model Section */}
      <section className="py-20 bg-slate-900/50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <h2 className="text-4xl md:text-5xl font-bold mb-6 bg-gradient-to-r from-blue-400 to-cyan-400 bg-clip-text text-transparent">
              Experience the Adaptive Suit
            </h2>
            <p className="text-xl text-gray-300 max-w-3xl mx-auto">
              Interact with our 3D model to explore the revolutionary features that make the Adaptive Suit the future of human enhancement technology.
            </p>
          </motion.div>
          
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            whileInView={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
          >
            <AdaptiveSuitModel />
          </motion.div>
        </div>
      </section>

      {/* Technology Section */}
      <section id="technology" className="py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <h2 className="text-4xl md:text-5xl font-bold mb-6 bg-gradient-to-r from-blue-400 to-cyan-400 bg-clip-text text-transparent">
              Core Technologies
            </h2>
            <p className="text-xl text-gray-300 max-w-3xl mx-auto">
              Built on cutting-edge innovations that redefine what's possible in human enhancement and global infrastructure.
            </p>
          </motion.div>

          <div className="grid md:grid-cols-3 gap-8">
            {[
              {
                icon: Shield,
                title: "Biomechanical Intelligence",
                description: "AI-powered systems that adapt to user physiology and cognitive needs in real-time."
              },
              {
                icon: Zap,
                title: "Modular Energy Systems",
                description: "Scalable renewable energy solutions designed for rapid deployment in any environment."
              },
              {
                icon: Globe,
                title: "Global Infrastructure",
                description: "Comprehensive connectivity solutions bringing internet and utilities to underserved regions."
              }
            ].map((tech, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.8, delay: index * 0.2 }}
                viewport={{ once: true }}
                className="bg-gradient-to-br from-slate-800 to-slate-700 rounded-xl p-6 text-center hover:shadow-xl transition-all duration-300"
              >
                <div className="w-16 h-16 bg-gradient-to-r from-blue-500 to-cyan-500 rounded-full flex items-center justify-center mx-auto mb-4">
                  <tech.icon size={32} className="text-white" />
                </div>
                <h3 className="text-xl font-bold mb-3">{tech.title}</h3>
                <p className="text-gray-300">{tech.description}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* About Section */}
      <section id="about" className="py-20 bg-slate-800/50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-2 gap-12 items-center">
            <motion.div
              initial={{ opacity: 0, x: -30 }}
              whileInView={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8 }}
              viewport={{ once: true }}
            >
              <h2 className="text-4xl md:text-5xl font-bold mb-6 bg-gradient-to-r from-blue-400 to-cyan-400 bg-clip-text text-transparent">
                About NewGen
              </h2>
              <p className="text-lg text-gray-300 mb-6">
                Founded in March 2025, NewGen Technologies emerged from a collegiate case competition and quickly evolved into a full-scale industrial innovation firm. We're committed to bringing tomorrow's technologies into today's world.
              </p>
              <p className="text-lg text-gray-300 mb-8">
                Our mission is driven by core values of Honesty, Integrity, Safety, Innovation, and Commitment. We serve both B2B and B2C markets, ensuring every product enhances lives while addressing the world's most urgent needs.
              </p>
              <div className="grid grid-cols-2 gap-6">
                <div className="text-center">
                  <div className="text-3xl font-bold text-blue-400">$2B+</div>
                  <div className="text-gray-300">Projected Revenue by Year 3</div>
                </div>
                <div className="text-center">
                  <div className="text-3xl font-bold text-cyan-400">20+</div>
                  <div className="text-gray-300">Countries Targeted</div>
                </div>
              </div>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, x: 30 }}
              whileInView={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8 }}
              viewport={{ once: true }}
              className="space-y-6"
            >
              {[
                { icon: Users, title: "Global Impact", description: "Serving governments, corporations, and individuals worldwide" },
                { icon: Shield, title: "Safety First", description: "Every product designed with safety and reliability as top priorities" },
                { icon: Zap, title: "Innovation Driven", description: "Pushing the boundaries of what's possible with cutting-edge R&D" }
              ].map((item, index) => (
                <div key={index} className="flex items-start space-x-4">
                  <div className="w-12 h-12 bg-gradient-to-r from-blue-500 to-cyan-500 rounded-lg flex items-center justify-center flex-shrink-0">
                    <item.icon size={24} className="text-white" />
                  </div>
                  <div>
                    <h3 className="text-xl font-semibold mb-2">{item.title}</h3>
                    <p className="text-gray-300">{item.description}</p>
                  </div>
                </div>
              ))}
            </motion.div>
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section id="contact" className="py-20">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
          >
            <h2 className="text-4xl md:text-5xl font-bold mb-6 bg-gradient-to-r from-blue-400 to-cyan-400 bg-clip-text text-transparent">
              Ready to Transform the Future?
            </h2>
            <p className="text-xl text-gray-300 mb-8">
              Join us in bringing tomorrow's technologies to today's world. Contact our team to explore partnership opportunities.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <motion.button
                className="bg-gradient-to-r from-blue-500 to-cyan-500 px-8 py-4 rounded-lg font-semibold text-lg hover:from-blue-600 hover:to-cyan-600 transition-all duration-200 shadow-lg hover:shadow-xl"
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
              >
                Schedule Consultation
              </motion.button>
              <motion.button
                className="border-2 border-blue-400 px-8 py-4 rounded-lg font-semibold text-lg hover:bg-blue-400 hover:text-slate-900 transition-all duration-200"
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
              >
                Download Brochure
              </motion.button>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-slate-900 py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <div className="flex items-center space-x-2 mb-4 md:mb-0">
              <div className="w-8 h-8 bg-gradient-to-r from-blue-400 to-cyan-400 rounded-lg flex items-center justify-center">
                <span className="text-slate-900 font-bold text-sm">NG</span>
              </div>
              <span className="text-xl font-bold bg-gradient-to-r from-blue-400 to-cyan-400 bg-clip-text text-transparent">
                NewGen Technologies
              </span>
            </div>
            <div className="text-gray-400 text-sm">
              © 2025 NewGen Technologies. All rights reserved.
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default App;

