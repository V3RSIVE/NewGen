import React, { useState, useRef, useEffect } from 'react';
import { motion, useAnimation } from 'framer-motion';
import { RotateCcw, Zap, Shield, Eye, Settings } from 'lucide-react';

const AdaptiveSuitModel = () => {
  const [rotation, setRotation] = useState({ x: 0, y: 0 });
  const [isDragging, setIsDragging] = useState(false);
  const [activeFeature, setActiveFeature] = useState(null);
  const [isAnimating, setIsAnimating] = useState(false);
  const modelRef = useRef(null);
  const controls = useAnimation();

  const features = [
    {
      id: 'power',
      name: 'Power Core',
      icon: Zap,
      position: { x: 50, y: 30 },
      description: 'Advanced energy management system with 24-hour battery life',
      color: 'from-yellow-400 to-orange-500'
    },
    {
      id: 'protection',
      name: 'Armor Plating',
      icon: Shield,
      position: { x: 30, y: 50 },
      description: 'Lightweight composite armor with impact resistance',
      color: 'from-blue-400 to-cyan-500'
    },
    {
      id: 'vision',
      name: 'HUD System',
      icon: Eye,
      position: { x: 50, y: 20 },
      description: 'Augmented reality heads-up display with AI assistance',
      color: 'from-green-400 to-emerald-500'
    },
    {
      id: 'control',
      name: 'Neural Interface',
      icon: Settings,
      position: { x: 70, y: 40 },
      description: 'Direct neural control for seamless human-machine integration',
      color: 'from-purple-400 to-pink-500'
    }
  ];

  const handleMouseDown = (e) => {
    setIsDragging(true);
    e.preventDefault();
  };

  const handleMouseMove = (e) => {
    if (!isDragging) return;
    
    const deltaX = e.movementX || 0;
    const deltaY = e.movementY || 0;
    
    setRotation(prev => ({
      x: Math.max(-45, Math.min(45, prev.x - deltaY * 0.5)),
      y: prev.y + deltaX * 0.5
    }));
  };

  const handleMouseUp = () => {
    setIsDragging(false);
  };

  const resetRotation = () => {
    setRotation({ x: 0, y: 0 });
  };

  const startAnimation = async () => {
    setIsAnimating(true);
    await controls.start({
      rotateY: [0, 360],
      transition: { duration: 3, ease: "easeInOut" }
    });
    setIsAnimating(false);
  };

  useEffect(() => {
    if (isDragging) {
      document.addEventListener('mousemove', handleMouseMove);
      document.addEventListener('mouseup', handleMouseUp);
      return () => {
        document.removeEventListener('mousemove', handleMouseMove);
        document.removeEventListener('mouseup', handleMouseUp);
      };
    }
  }, [isDragging]);

  return (
    <div className="w-full max-w-4xl mx-auto bg-gradient-to-br from-slate-800 to-slate-700 rounded-2xl p-8 shadow-2xl">
      <div className="text-center mb-8">
        <h3 className="text-3xl font-bold mb-4 bg-gradient-to-r from-blue-400 to-cyan-400 bg-clip-text text-transparent">
          Interactive Adaptive Suit Model
        </h3>
        <p className="text-gray-300">
          Explore the suit's features by clicking on the hotspots or drag to rotate the model
        </p>
      </div>

      <div className="relative">
        {/* 3D Model Container */}
        <div className="relative w-full h-96 bg-gradient-to-br from-slate-900 to-slate-800 rounded-xl overflow-hidden border border-slate-600">
          <motion.div
            ref={modelRef}
            className="w-full h-full flex items-center justify-center cursor-grab active:cursor-grabbing"
            style={{
              transform: `perspective(1000px) rotateX(${rotation.x}deg) rotateY(${rotation.y}deg)`,
              transformStyle: 'preserve-3d'
            }}
            animate={controls}
            onMouseDown={handleMouseDown}
          >
            {/* Suit Silhouette */}
            <div className="relative w-48 h-80 bg-gradient-to-b from-slate-600 to-slate-700 rounded-t-full rounded-b-lg shadow-2xl">
              {/* Helmet */}
              <div className="absolute top-0 left-1/2 transform -translate-x-1/2 w-20 h-20 bg-gradient-to-b from-slate-500 to-slate-600 rounded-full border-2 border-blue-400/50">
                <div className="absolute top-2 left-1/2 transform -translate-x-1/2 w-12 h-8 bg-blue-400/30 rounded-lg"></div>
              </div>
              
              {/* Chest Piece */}
              <div className="absolute top-16 left-1/2 transform -translate-x-1/2 w-32 h-24 bg-gradient-to-b from-slate-500 to-slate-600 rounded-lg">
                <div className="absolute top-2 left-1/2 transform -translate-x-1/2 w-8 h-8 bg-yellow-400/50 rounded-full animate-pulse"></div>
              </div>
              
              {/* Arms */}
              <div className="absolute top-20 left-2 w-8 h-32 bg-gradient-to-b from-slate-500 to-slate-600 rounded-lg"></div>
              <div className="absolute top-20 right-2 w-8 h-32 bg-gradient-to-b from-slate-500 to-slate-600 rounded-lg"></div>
              
              {/* Legs */}
              <div className="absolute bottom-0 left-1/2 transform -translate-x-1/2 translate-x-4 w-12 h-40 bg-gradient-to-b from-slate-600 to-slate-700 rounded-b-lg"></div>
              <div className="absolute bottom-0 left-1/2 transform -translate-x-1/2 -translate-x-4 w-12 h-40 bg-gradient-to-b from-slate-600 to-slate-700 rounded-b-lg"></div>
              
              {/* Glowing Effects */}
              <div className="absolute inset-0 bg-gradient-to-r from-blue-400/10 to-cyan-400/10 rounded-t-full rounded-b-lg animate-pulse"></div>
            </div>

            {/* Feature Hotspots */}
            {features.map((feature) => (
              <motion.div
                key={feature.id}
                className={`absolute w-4 h-4 bg-gradient-to-r ${feature.color} rounded-full cursor-pointer shadow-lg border-2 border-white/50`}
                style={{
                  left: `${feature.position.x}%`,
                  top: `${feature.position.y}%`,
                  transform: 'translate(-50%, -50%)'
                }}
                whileHover={{ scale: 1.5 }}
                whileTap={{ scale: 0.9 }}
                animate={{
                  boxShadow: activeFeature === feature.id 
                    ? '0 0 20px rgba(59, 130, 246, 0.8)' 
                    : '0 0 10px rgba(59, 130, 246, 0.4)'
                }}
                onClick={() => setActiveFeature(activeFeature === feature.id ? null : feature.id)}
              >
                <div className="absolute inset-0 bg-white/20 rounded-full animate-ping"></div>
              </motion.div>
            ))}
          </motion.div>

          {/* Grid Background */}
          <div className="absolute inset-0 opacity-20 pointer-events-none">
            <div className="w-full h-full" style={{
              backgroundImage: `
                linear-gradient(rgba(59, 130, 246, 0.3) 1px, transparent 1px),
                linear-gradient(90deg, rgba(59, 130, 246, 0.3) 1px, transparent 1px)
              `,
              backgroundSize: '20px 20px'
            }}></div>
          </div>
        </div>

        {/* Controls */}
        <div className="flex justify-center mt-6 space-x-4">
          <motion.button
            className="flex items-center space-x-2 bg-slate-700 hover:bg-slate-600 px-4 py-2 rounded-lg transition-colors duration-200"
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            onClick={resetRotation}
          >
            <RotateCcw size={16} />
            <span>Reset View</span>
          </motion.button>
          
          <motion.button
            className="flex items-center space-x-2 bg-blue-600 hover:bg-blue-500 px-4 py-2 rounded-lg transition-colors duration-200 disabled:opacity-50"
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            onClick={startAnimation}
            disabled={isAnimating}
          >
            <Zap size={16} />
            <span>{isAnimating ? 'Animating...' : 'Auto Rotate'}</span>
          </motion.button>
        </div>

        {/* Feature Information Panel */}
        {activeFeature && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 20 }}
            className="mt-6 bg-slate-800 rounded-xl p-6 border border-slate-600"
          >
            {(() => {
              const feature = features.find(f => f.id === activeFeature);
              const IconComponent = feature.icon;
              return (
                <div className="flex items-start space-x-4">
                  <div className={`w-12 h-12 bg-gradient-to-r ${feature.color} rounded-lg flex items-center justify-center`}>
                    <IconComponent size={24} className="text-white" />
                  </div>
                  <div>
                    <h4 className="text-xl font-semibold mb-2">{feature.name}</h4>
                    <p className="text-gray-300">{feature.description}</p>
                  </div>
                </div>
              );
            })()}
          </motion.div>
        )}

        {/* Technical Specifications */}
        <div className="mt-8 grid md:grid-cols-2 gap-6">
          <div className="bg-slate-800 rounded-xl p-6 border border-slate-600">
            <h4 className="text-lg font-semibold mb-4 text-blue-400">Technical Specs</h4>
            <div className="space-y-2 text-sm">
              <div className="flex justify-between">
                <span className="text-gray-400">Weight:</span>
                <span>15.2 kg</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-400">Battery Life:</span>
                <span>24 hours</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-400">Max Load:</span>
                <span>200 kg</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-400">Operating Temp:</span>
                <span>-40°C to 60°C</span>
              </div>
            </div>
          </div>

          <div className="bg-slate-800 rounded-xl p-6 border border-slate-600">
            <h4 className="text-lg font-semibold mb-4 text-cyan-400">Key Features</h4>
            <div className="space-y-2 text-sm">
              <div className="flex items-center space-x-2">
                <div className="w-2 h-2 bg-green-400 rounded-full"></div>
                <span>Neural Interface Control</span>
              </div>
              <div className="flex items-center space-x-2">
                <div className="w-2 h-2 bg-green-400 rounded-full"></div>
                <span>Modular Component System</span>
              </div>
              <div className="flex items-center space-x-2">
                <div className="w-2 h-2 bg-green-400 rounded-full"></div>
                <span>Real-time Health Monitoring</span>
              </div>
              <div className="flex items-center space-x-2">
                <div className="w-2 h-2 bg-green-400 rounded-full"></div>
                <span>Environmental Adaptation</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AdaptiveSuitModel;

